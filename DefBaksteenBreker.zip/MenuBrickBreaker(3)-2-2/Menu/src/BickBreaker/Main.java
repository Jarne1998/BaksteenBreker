package BickBreaker;

import BickBreaker.Model.MenuModel;
import BickBreaker.view.menu.MenuPresenter;
import BickBreaker.view.menu.MenuView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Hier wordt de CSS en het menu opgeroepen met te titel Brick Breaker en
 * met een scherm grote
 *
 * @author Jarne Bauwens, Ruben Jansens
 * @version 3.0
 */
public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        MenuModel model = new MenuModel();
        MenuView view = new MenuView();
        MenuPresenter presenter = new MenuPresenter(model, view);
        primaryStage.setScene(new Scene(view));
        view.getStylesheets().add("CSS//main.css");
        presenter.addWindowEventHandlers();

        primaryStage.setTitle("Brick Breaker");
        primaryStage.setMinWidth(800);
        primaryStage.setMinHeight(500);
        primaryStage.setResizable(true);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
