package BickBreaker.view.menu;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

/**
 * De klasse MenuView die er voor zorgt dat alles wordt gevisualizeerd
 */
public class MenuView extends VBox {
    private Button NewGameButton, HighscoreButton, HelpButton;
    private Label label;

    /**
     * Constructor van de klasse HelpView.
     * Vult alle variabelen in en initialisieerd en localiseerd de Nodes
     */
    public MenuView(){
        initialiseNodes();
        layoutNodes();
    }

    /**
     * Initialisatie van de Nodes
     */
    private void initialiseNodes() {
        NewGameButton = new Button("New Game");
        HighscoreButton = new Button("Highscore");
        HelpButton = new Button("Help");
        NewGameButton.setLineSpacing(100);
    }

    /**
     * Localisatie van de Nodes, positie van de knoppen en zet een achtergrond
     */
    private void layoutNodes(){

        setSpacing(10);
        setPadding(new Insets(10));
        getChildren().addAll( NewGameButton, HighscoreButton, HelpButton);
        setAlignment(Pos.CENTER);
        
        this.setBackground(new Background(new BackgroundImage(new Image("Achtergrond9.jpg"), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, new BackgroundPosition(
                Side.LEFT, 0.0, false, Side.BOTTOM, 0.0, false), BackgroundSize.DEFAULT)));
    }

    /**
     * Standaard get
     *
     * @return geeft de NewGameButton terug
     */
    public Button getNewGameButton() {
        return NewGameButton;
    }

    /**
     * Standaard get
     *
     * @return geeft de HighscoreButton terug
     */
    public Button getHighscoreButton() {
        return HighscoreButton;
    }

    /**
     * Standaard get
     *
     * @return geeft de HelpButton terug
     */
    public Button getHelpButton() {
        return HelpButton;
    }
}
