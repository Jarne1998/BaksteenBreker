package BickBreaker.view.newgame;

import BickBreaker.Model.GameModel;
import BickBreaker.Model.MenuModel;
import BickBreaker.Model.NewGameModel;
import BickBreaker.view.game.GamePresenter;
import BickBreaker.view.game.GameView;
import BickBreaker.view.menu.MenuPresenter;
import BickBreaker.view.menu.MenuView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;

public class NewGamePresenter {
    private NewGameView view;
    private NewGameModel model;
    private  String naam;

    /**
     * Constructor van de klasse NeweGamePresenter
     *
     * @param model Model parameter
     * @param view View parameter
     */
    public NewGamePresenter(NewGameView view, NewGameModel model) {
        this.model = model;
        this.view = view;
        this.addEventHandlers();
        this.updateView();
        this.addWindowEventHandlers();
    }

    /**
     * Handeld alle evenementen af van buttons
     */
    private void addEventHandlers() {
        view.getNextScene().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                naam = view.getGevenNaam().getText();
                if ((naam.length()) > 8) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setContentText("Te veel charachters! (max 8)");
                    alert.show();
                } else {
                    GameView gameView = new GameView();
                    GameModel gameModel = new GameModel();
                    gameView.createGameloop(gameModel);
                    view.getScene().setRoot(gameView);
                    GamePresenter gamePresenter = new GamePresenter(gameModel, gameView);
                    gamePresenter.setName(naam);
                }

            }
        });

        view.getMenuBack_btn().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                MenuView menuView = new MenuView();
                MenuModel menuModel = new MenuModel();
                MenuPresenter menuPresenter = new MenuPresenter(menuModel, menuView);
                view.getScene().setRoot(menuView);
            }
        });
    }

    private void updateView() {
    }

    public void addWindowEventHandlers() {
    }


}
