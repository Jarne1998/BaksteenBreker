package BickBreaker.view.game;

import BickBreaker.Model.GameModel;
import BickBreaker.Model.MenuModel;
import BickBreaker.view.menu.MenuPresenter;
import BickBreaker.view.menu.MenuView;
import TextFiles.WriteToFile;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.WindowEvent;

import java.util.Optional;

public class GamePresenter {
    private GameModel model;
    private GameView view;
    private String name;

    /**
     * Constructor van de klasse GamePresenter
     *
     * @param model GameModel parameter
     * @param view GameView parameter
     */
    public GamePresenter(GameModel model, GameView view) {
        this.model = model;
        this.view = view;

        updateView();
        handleEvents();
    }

    public void setName(String name) {
        this.name = name;
    }

    private void updateView() {

    }

    /**
     * Handeld alle evenementen af van buttons, close requests...
     */
    private void handleEvents() {
        view.getPauseButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                view.getVelocitySlider().setDisable(!view.getVelocitySlider().isDisabled());
                view.reDrawCanvas();
                model.setPaused();
            }
        });

        view.getVelocitySlider().valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> ov, Number old_val, Number new_val) {
                if (model.getPlayerIsControlling()) {
                    model.setVelocityX(new_val.doubleValue());
                    model.setVelocityY(-5 + Math.abs(new_val.doubleValue()) - 1);
                    view.drawTrajectory(model.calculateTrajectory(new_val.doubleValue()));
                }
            }
        });

        view.getVelocitySlider().setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (model.getPlayerIsControlling()) {
                    model.setPlayerIsControlling();
                }
                view.getVelocitySlider().setValue(0);
            }
        });

        view.getAlert().setOnCloseRequest(new EventHandler<DialogEvent>() {
            @Override
            public void handle(DialogEvent event) {
                WriteToFile write = new WriteToFile();
                write.openFile("Menu/resources/highscores.txt");
                write.write(name, model.getRound());
                write.closeFile();
                MenuView menuView = new MenuView();
                MenuModel menuModel = new MenuModel();
                view.getScene().setRoot(menuView);
                view.setMinHeight(500);
                view.setMinWidth(800);
                MenuPresenter menuPresenter = new MenuPresenter(menuModel, menuView);
            }
        });

        view.getScene().getWindow().setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                if (!model.isPaused()) {
                    model.setPaused();
                }
                view.getVelocitySlider().setDisable(true);
                final Alert closeConfimation = new Alert(Alert.AlertType.CONFIRMATION);
                closeConfimation.setHeaderText("Bent u zeker?");
                closeConfimation.setContentText("Al uw niet opgeslagen progres gaat verloren.");
                Optional<ButtonType> choise = closeConfimation.showAndWait();
                if (choise.get().getText().equalsIgnoreCase("CANCEL")) {
                    event.consume();
                }
            }
        });
    }
}
