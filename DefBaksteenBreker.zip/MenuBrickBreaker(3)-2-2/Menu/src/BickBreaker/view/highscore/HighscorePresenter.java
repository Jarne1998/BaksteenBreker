package BickBreaker.view.highscore;

import BickBreaker.Model.HighscoreModel;
import BickBreaker.Model.MenuModel;
import BickBreaker.view.menu.MenuPresenter;
import BickBreaker.view.menu.MenuView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class HighscorePresenter {
    private HighscoreView view;
    private HighscoreModel model;

    /**
     * Constructor van de klasse HighScorePresenter
     *
     * @param model Model parameter
     * @param view View parameter
     */
    public HighscorePresenter(HighscoreView view, HighscoreModel model) {
        this.model = model;
        this.view = view;
        this.addEventHandlers();
    }

    /**
     * Handeld alle evenementen af van buttons
     */
    private void addEventHandlers() {
        view.getNextScene().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                MenuView menuView = new MenuView();
                MenuModel menuModel = new MenuModel();
                MenuPresenter menuPresenter = new MenuPresenter(menuModel, menuView);
                view.getScene().setRoot(menuView);
            }
        });
    }
}
