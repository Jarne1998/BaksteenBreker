package BickBreaker.view.help;

import BickBreaker.Model.HelpModel;
import BickBreaker.Model.MenuModel;
import BickBreaker.view.menu.MenuPresenter;
import BickBreaker.view.menu.MenuView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class HelpPresenter {
    private HelpView view;
    private HelpModel model;

    /**
     * Constructor van de klasse HelpPresenter
     *
     * @param model Model parameter
     * @param view View parameter
     */
    public HelpPresenter(HelpView view, HelpModel model) {
        this.model = model;
        this.view = view;
        this.addEventHandlers();
        this.updateView();
    }

    /**
     * Handeld alle evenementen af van buttons
     */
    private void addEventHandlers() {
        view.getNextScene().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                MenuView menuView = new MenuView();
                MenuModel menuModel = new MenuModel();
                MenuPresenter menuPresenter = new MenuPresenter(menuModel, menuView);
                view.getScene().setRoot(menuView);
            }
        });
    }

    public void updateView() {
    }
}