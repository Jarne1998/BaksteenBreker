package BickBreaker.Model;

/**
 * Lege constructor
 */
public class HelpModel {
    public HelpModel() {
    }
}
