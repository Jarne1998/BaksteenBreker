package BickBreaker.Model;

/**
 * Lege constructor
 */
public class MenuModel {
    public MenuModel(){
    }
}
