package BickBreaker.Model;

/**
 * Lege constructor
 */
public class NewGameModel {
}
