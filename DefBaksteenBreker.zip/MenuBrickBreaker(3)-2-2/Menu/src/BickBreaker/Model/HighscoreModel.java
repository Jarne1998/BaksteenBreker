package BickBreaker.Model;

        /**
        * Lege constructor
        */
public class HighscoreModel {
    public HighscoreModel() {
    }
}
