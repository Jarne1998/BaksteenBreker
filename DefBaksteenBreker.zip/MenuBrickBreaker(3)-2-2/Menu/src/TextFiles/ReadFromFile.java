package TextFiles;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;


public class ReadFromFile {
    private BufferedReader in;
    private ObservableList<User> users;

    public void openFile(String fileName) {
        try {
            in = new BufferedReader(new FileReader(fileName));
        } catch (Exception ex) {
            System.out.println("Error open file");
        }
    }

    public ObservableList<User> read() {
        try {
            users = FXCollections.observableArrayList();

            String line = null;
            while ((line = in.readLine()) != null) {
                String[] parts = line.split("-");
                users.add(new User(parts[0], Integer.parseInt(parts[1])));
            }
            return users;
        } catch (Exception ex) {
            System.out.println("Error read file");
        }
        return null;
    }

    public void closeFile() {
        try {
            in.close();
        } catch (Exception ex) {
            System.out.println("Error close file");
        }
    }
}
