package Objects;

import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

import java.util.ArrayList;
import java.util.List;

/**
 * De klasse RectangleSprite is de klasse die alle informatie bijhoudt van 1 object dat telkens wordt uitgetekent.
 * Dit kan gaan over een speler bal, een gewone blok, een extra bal blok of een power blok.
 *
 * @author Ruben Janssens
 * @version ?
 */
public class RectangleSprite {
    private Image image;
    private int hitpoints;
    private double positionX;
    private double positionY;
    private double velocityX;
    private double velocityY;
    private double width;
    private double height;
    private SpriteType type;
    private List<RectangleSprite> ballsInRange;

    /**
     * Constructor van de klasse RectangleSprite voor bewegende objecten en vult de variabelen in.
     *
     * @param type het type blok dat de klasse zal aannemen
     * @param posX de positie X op het canvas
     * @param posY de positie Y op het canvas
     * @param velocityX de kracht die op de X positie wordt uitgeoefend
     * @param velocityY de kracht die op de Y positie wordt uitgeoefend
     * @param url de locatie van de foto die de klasse moet gebruiken
     */
    public RectangleSprite(SpriteType type , double posX, double posY, double velocityX, double velocityY, String url) {
        this.type = type;
        this.image = new Image(url);
        this.positionX = posX;
        this.positionY = posY;
        this.velocityX = velocityX *2;
        this.velocityY = (velocityY -1) *2;

        this.height = image.getHeight();
        this.width = image.getWidth();
    }

    /**
     * Constructor van de klasse RectangleSprite voor statishe objecten
     *
     * @param type het type blok dat de klasse zal aannemen
     * @param posX de positie X op het canvas
     * @param posY de positie Y op het canvas
     * @param url de llocatie van de foto die de klasse moet gebruiken
     * @param hitPoints het aantal levens het object zal hebben
     */
    public RectangleSprite(SpriteType type , double posX, double posY, String url, int hitPoints) {
        this.type = type;
        this.image = new Image(url);
        this.positionX = posX;
        this.positionY = posY;
        this.hitpoints = hitPoints;

        this.height = image.getHeight();
        this.width = image.getWidth();
        ballsInRange = new ArrayList<>();
    }

    /**
     * Als het een een beweegend object is zal deze functie opgeroepen worden om de positie te updaten
     *
     */
    public void update()
    {
        if (positionX < 0 || positionX > 630) {
            velocityX = -velocityX;
        }
        if (positionY < 0) {
            velocityY = -velocityY;
        }

        positionX += velocityX ;
        positionY += velocityY ;
    }

    /**
     * Veranderd de kracht die op het object worden uitgeoefend tegenover een ander object van de klasse RectangleSprite.
     *
     * @param block de blok waar de bal heeft tegen gebotst
     */
    public void changeVelocity(RectangleSprite block) {
        if (type == SpriteType.PLAYER) {
            if ((positionX + (width/2) >= block.positionX + block.width || positionX + (width/2) <= block.positionX) && positionY <= block.positionY + block.height && positionY + height >= block.positionY) {
                velocityX = -velocityX;
            } else if ((positionY + (height/2) >= block.positionY + block.height || positionY + (height/2) <= block.positionY) && positionX <= block.positionX + block.width && positionX + width >= block.positionX){
                velocityY = -velocityY;
            }
        }
    }

    /**
     * Vermindert de hitpoints met een bepaalde hoeveelheid.
     *
     * @param dmg bepaalde hoeveelheid damage
     */
    public void takeDamage(double dmg) {
        hitpoints -= dmg;
    }

    /**
     * Tekent het object op de canvas en als het object van het type BLOCK is zal ook de hoeveelheid hitpoints worden getekend
     *
     * @param gc de GraphicsContext van het canvas
     */
    public void render(GraphicsContext gc)
    {
        gc.drawImage( image, positionX, positionY);
        if (type == SpriteType.BLOCK) { gc.fillText(Integer.toString(hitpoints), positionX + 5 + 10 , positionY + 40, 30); }
    }

    /**
     * Berekent de grote van het oppervlak aan de hand van de X en Y positie en de hoogte en breedte van de foto
     *
     * @return geeft een Rectangle2D object terug om verdere berkeningen te kunnen doen
     */
    public Rectangle2D getBoundary()
    {
        return new Rectangle2D(positionX,positionY,width,height);
    }

    /**
     * Checkt of een object met dit object kruist
     *
     * @param r het andere object
     * @return geeft true/false terug of de objecten kruisen of niet
     */
    public boolean intersects(RectangleSprite r)
    {
        return r.getBoundary().intersects(this.getBoundary());
    }

    /**
     * Standaard get
     *
     * @return geeft de hitpoints terug
     */
    public double getHitpoints() {
        return hitpoints;
    }

    /**
     * Standaard get
     *
     * @return geeft de Y positie terug
     */
    public double getPositionY() {
        return positionY;
    }

    /**
     * Standaard get
     *
     * @return geeft de X positie terug
     */
    public double getPositionX() {
        return positionX;
    }

    /**
     * Standaard set
     *
     * @param positionX de X positie die moet worden gebruikt
     */
    public void setPositionX(double positionX) {
        this.positionX = positionX;
    }

    /**
     * Standaard set
     *
     * @param positionY de Y positie die moet worden gebruikt
     */
    public void setPositionY(double positionY) {
        this.positionY = positionY;
    }

    /**
     * Standaard get
     *
     * @return geeft het type object terug
     */
    public SpriteType getType() {
        return type;
    }

    /**
     * Standaard get
     *
     * @return geeft de lijst ballsInRange terug
     */
    public List<RectangleSprite> getBallsInRange() {
        return ballsInRange;
    }
}