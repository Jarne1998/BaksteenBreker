package BickBreaker.Model;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.text.Font;
import objects.RectangleSprite;
import objects.spriteType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class GameModel {
    private AnimationTimer gameLoop;
    private int timer = 0;
    private boolean paused = false;
    private int maxBalls = 20;
    private int curBalls = 0;
    private int ballsToAdd = 0;
    private double startPosY = 120;
    private double velocityX;
    private double velocityY;
    private Random rand;
    GraphicsContext gc;

    ArrayList<RectangleSprite> playerBalls = new ArrayList<>();
    ArrayList<RectangleSprite> blocks = new ArrayList<>();
    ArrayList<RectangleSprite> hitBlocks = new ArrayList<>();
    ArrayList<RectangleSprite> blocksToRemoveAfterRound = new ArrayList<>();
    ArrayList<RectangleSprite> ballsGone = new ArrayList<>();
    ArrayList<RectangleSprite> ballsStillInRange = new ArrayList<>();

    ArrayList<Integer> blockPicker = new ArrayList<>();

    public GameModel() {
        //Load in blocks
            for (int x = 0; x < 11; x++) {
                blocks.add(new RectangleSprite(spriteType.BLOCK,x * 60, 60, "/Block2.png", 10));
            }
        rand = new Random();
        velocityX = rand.nextDouble() +4;
        velocityY = rand.nextDouble() -5;

        //regular
        for (int i = 0; i< 75; i++) {
            blockPicker.add(0);
        }
        //extra ball
        for (int i = 0; i< 20; i++) {
            blockPicker.add(1);
        }
        //power
        for(int i = 0; i<5; i++) {
            blockPicker.add(2);
        }
    }

    public void setPaused() {
        this.paused = !this.paused;
    }

    public void setGc(GraphicsContext gc) {
        this.gc = gc;
    }

    public void createGameLoop() {
        gameLoop = new AnimationTimer() {
            public void handle(long currentNanoTime) {
                if (!paused) {
                    if (playerBalls.size() == 0 && timer==0 && curBalls != 0) {
                        for (RectangleSprite block: blocks) {
                            block.setPositionY(block.getPositionY() + 60);
                            if(block.getType() == spriteType.EXTRABALL && block.getPositionY() == 540) {
                                blocksToRemoveAfterRound.add(block);
                            }
                        }
                        if (blocks.get(0).getPositionY() == 540 && blocks.get(0).getType() == spriteType.BLOCK) {
                            gc.clearRect(0, 0, 1100, 600);
                            gc.setFont(new Font(50));
                            gc.fillText("GAME OVER", 300,300);
                            gameLoop.stop();
                        }

                        for (RectangleSprite block: blocksToRemoveAfterRound) {
                            blocks.remove(block);
                        }

                        blocksToRemoveAfterRound.clear();

                        for (int x = 0; x < 11; x++) {
                            Collections.shuffle(blockPicker);
                            if (blockPicker.get(0) == 0) {
                                blocks.add(new RectangleSprite(spriteType.BLOCK,x * 60, 60, "/Block2.png", 10));
                            } else if (blockPicker.get(0) == 1) {
                                blocks.add(new RectangleSprite(spriteType.EXTRABALL, x*60 + 15,60+15,"/ExtraBall.png", -1));
                            } else if (blockPicker.get(0) == 2) {
                                blocks.add(new RectangleSprite(spriteType.POWER, x*60+15 ,60+15,"/Power.png",-2));
                                blocksToRemoveAfterRound.add(blocks.get(blocks.size()-1));
                            }
                        }
                        curBalls = 0;
                        //paused = true;
                        velocityX = rand.nextDouble() +4;
                        velocityY = rand.nextDouble() -5;
                        if (startPosY <= 540) {
                            startPosY += 120;
                        }else {
                            startPosY = 120;
                        }

                        maxBalls += ballsToAdd;
                        ballsToAdd=0;
                    }

                    if (curBalls < maxBalls && timer == 4) {
                        playerBalls.add(new RectangleSprite(spriteType.PLAYER,startPosY, 540,velocityX,velocityY, "/Ball.png"));
                        timer = 0;
                        curBalls++;
                    } else if (curBalls < maxBalls) {
                        timer++;
                    }

                    for (RectangleSprite ball : playerBalls) {
                        for (RectangleSprite block : blocks) {
                            if (ball.intersects(block) && !block.getBallsInRange().contains(ball)) {
                                block.getBallsInRange().add(ball);
                                if (block.getType() == spriteType.BLOCK) {
                                    ball.changeVelocity(block);
                                    block.takeDamage(1);
                                    if (!hitBlocks.contains(block)) {
                                        hitBlocks.add(block);
                                    }
                                    System.out.println("hit");
                                    break;
                                } else if (block.getType() == spriteType.EXTRABALL) {
                                    hitBlocks.add(block);
                                    ballsToAdd++;
                                } else if (block.getType() == spriteType.POWER) {
                                    if (!ballsStillInRange.contains(ball)) {
                                        ballsStillInRange.add(ball);
                                        if (!blocksToRemoveAfterRound.contains(block)) {
                                            blocksToRemoveAfterRound.add(block);
                                        }
                                        for (RectangleSprite block2 : blocks) {
                                            if (block2.getPositionY() + 15 == block.getPositionY() && block2.getType() == spriteType.BLOCK) {
                                                block2.takeDamage(1);
                                                if (!hitBlocks.contains(block2)) {
                                                    hitBlocks.add(block2);
                                                }
                                            }
                                        }
                                    }
                                }

                            }
                            if (!ball.intersects(block)){
                                block.getBallsInRange().remove(ball);
                            }
                        }
                        if (ball.getPositionY() > 550) {
                            ballsGone.add(ball);
                        }
                    }


                    for (RectangleSprite block : hitBlocks) {
                        if (block.getHitpoints() <= 0) {
                            blocks.remove(block);
                        }
                    }

                    for (RectangleSprite ball : ballsGone) {
                        playerBalls.remove(ball);
                    }

                    hitBlocks.clear();

                    gc.clearRect(0, 0, 1100, 600);

                    for (RectangleSprite ball : playerBalls) {
                        ball.update(0.5);
                        ball.render(gc);
                    }

                    for (RectangleSprite block : blocks) {
                        block.render(gc);
                    }

                    gc.fillText("Balls:" + Integer.toString(maxBalls), 100,10);
                }
            }
        };

        gameLoop.start();
    }
}

