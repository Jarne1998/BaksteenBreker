package BickBreaker.Model;

public class HelpModel {
    public HelpModel() {
    }
}
