package BickBreaker.view.help;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class HelpView extends VBox {
    private Button Back_btn;
    private Label Help;
    private Label Instructies1;
    private Label Instructies2;
    private Label Instructies3;
    private Label Instructen4;
    private Label Instructen5;
    private Label Instructen6;
    private Label Instructen7;

    public HelpView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {

        Help = new Label("Help");
        Back_btn = new Button("Terug");
        Instructies1 = new Label("Hier kan je zien hoe dit spel wordt gespeeld en wat de speelregels zijn:");
        Instructies2 = new Label("Je kan blokken laten verdwijnen door er de hoeveelheid ballen er op te schieten dat vermeld staat op de blok.");
        Instructies3 = new Label("De pijlenen omhoog zijn de extra ballen die je kan verkrijgen door er op de schieten.");
        Instructen4 = new Label("De sterren zijn de stralen die een horizontale of verticale lijn blokken kan laten verdwijnen.");
        Instructen5 = new Label("Door de horizontale bar onderaan het scherm kan je kiezen naar waar je de ballen schiet.");
    }

    private void layoutNodes() {
        Instructies1.setTextFill(Color.BLACK);
        Instructies2.setTextFill(Color.BLACK);
        Instructies3.setTextFill(Color.BLACK);
        Instructen4.setTextFill(Color.BLACK);
        Instructen5.setTextFill(Color.BLACK);
        /*Instructen6.setTextFill(Color.BLACK);
        Instructen7.setTextFill(Color.BLACK);*/

        setSpacing(10);
        setPadding(new Insets(10));
        getChildren().addAll(Help, Instructies1, Instructies2, Instructies3, Back_btn);
        setAlignment(Pos.CENTER);

        this.setBackground(new Background(new BackgroundImage(new Image("Achtergrond9.jpg"), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, new BackgroundPosition(
                Side.LEFT, 0.0, false, Side.BOTTOM, 0.0, false), BackgroundSize.DEFAULT)));

       /* getChildren().add(Back);
        setAlignment(Pos.TOP_LEFT); */
    }

    public Button getNextScene() {
        return Back_btn;
    }
}