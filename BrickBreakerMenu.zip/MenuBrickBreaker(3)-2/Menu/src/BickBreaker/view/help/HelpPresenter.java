package BickBreaker.view.help;

import BickBreaker.Model.HelpModel;
import BickBreaker.Model.MenuModel;
import BickBreaker.view.menu.MenuPresenter;
import BickBreaker.view.menu.MenuView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class HelpPresenter {
    private HelpView view;
    private HelpModel model;

    public HelpPresenter(HelpView view, HelpModel model) {
        this.model = model;
        this.view = view;
        this.addEventHandlers();
        this.updateView();
    }

    private void addEventHandlers() {
        view.getNextScene().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                MenuView menuView = new MenuView();
                MenuModel menuModel = new MenuModel();
                MenuPresenter menuPresenter = new MenuPresenter(menuModel, menuView);
                view.getScene().setRoot(menuView);
                //menuView.getScene().getWindow().sizeToScene();
            }
        });
    }

    public void updateView() {
    }
}