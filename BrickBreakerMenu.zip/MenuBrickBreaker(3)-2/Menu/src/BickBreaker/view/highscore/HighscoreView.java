package BickBreaker.view.highscore;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

public class HighscoreView extends VBox {
    private Label HighscoreLabel;
    private Button Back_btn;
    private Label HighscoreScoreLabel1;
    private Label HighscoreScoreLabel2;
    private Label HighscoreScoreLabel3;
    private Label HighscoreScoreLabel4;
    private Label HighscoreScoreLabel5;
    private Label HighscoreScoreLabel6;
    private Label HighscoreScoreLabel7;
    private Label HighscoreScoreLabel8;
    private Label HighscoreScoreLabel9;
    private Label HighscoreScoreLabel10;

    GridPane gridPane = new GridPane();

    public HighscoreView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        Back_btn = new Button("Terug");
        HighscoreLabel = new Label("Highscore");
        HighscoreScoreLabel1 = new Label(" ");
        HighscoreScoreLabel2 = new Label(" ");
        HighscoreScoreLabel3 = new Label("");
        HighscoreScoreLabel4 = new Label(" ");
    }

    private void layoutNodes() {

        setSpacing(10);
        setPadding(new Insets(10));
        getChildren().addAll(HighscoreLabel, Back_btn);
        setAlignment(Pos.CENTER);

        gridPane.add(HighscoreScoreLabel1,0, 0, 1, 1);

        this.setBackground(new Background(new BackgroundImage(new Image("Achtergrond9.jpg"), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, new BackgroundPosition(
                Side.LEFT, 0.0, false, Side.BOTTOM, 0.0, false), BackgroundSize.DEFAULT)));
    }

    public Button getNextScene() {
        return Back_btn;
    }
}
