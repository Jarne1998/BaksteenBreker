package BickBreaker.view.game;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;

public class GameView extends BorderPane {


    private Canvas canvas;
    private Button pauseButton;
    private Slider velocitySlider;
    private Label scoreLabel;

    public GameView() {
        initialiseNodes();
        layoutNodes();
        setStyle("-fx-background-color: white");
    }

    public void initialiseNodes() {
        canvas = new Canvas(660,600);
        pauseButton = new Button("Pause");
        velocitySlider = new Slider();

        velocitySlider.setMin(-1);
        velocitySlider.setMax(1);
        velocitySlider.setValue(0);
        velocitySlider.setShowTickLabels(false);
        velocitySlider.setShowTickMarks(false);
        velocitySlider.setMaxWidth(200);
    }

    public void layoutNodes() {
        BorderPane.setMargin(pauseButton, new Insets(10));
        BorderPane.setAlignment(pauseButton, Pos.CENTER_RIGHT);
        BorderPane.setAlignment(velocitySlider, Pos.CENTER);
        setTop(pauseButton);
        setCenter(canvas);
        setBottom(velocitySlider);
    }

    public Canvas getCanvas() {
        return canvas;
    }

    public Button getPauseButton() {
        return pauseButton;
    }

}
