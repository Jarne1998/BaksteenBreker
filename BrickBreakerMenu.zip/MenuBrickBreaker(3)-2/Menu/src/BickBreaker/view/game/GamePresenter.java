package BickBreaker.view.game;

import BickBreaker.Model.GameModel;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class GamePresenter {
    private GameModel model1;
    private GameView view1;

    public GamePresenter(GameModel model1, GameView view1) {
        this.model1 = model1;
        this.view1 = view1;

        updateView();
        handleEvents();

        this.addWindowEventHandlers();
    }

    private void updateView() {

    }

    private void handleEvents() {
        view1.getPauseButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                model1.setPaused();
            }
        });
    }

    private void addWindowEventHandlers(){
    }
}
