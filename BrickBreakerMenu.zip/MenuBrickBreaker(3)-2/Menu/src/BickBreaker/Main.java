package BickBreaker;

import BickBreaker.Model.GameModel;
import BickBreaker.Model.MenuModel;
import BickBreaker.view.game.GamePresenter;
import BickBreaker.view.game.GameView;
import BickBreaker.view.menu.MenuPresenter;
import BickBreaker.view.menu.MenuView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import org.testng.annotations.Test;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        GameModel gameModel = new GameModel();
        GameView gameView = new GameView();
        GamePresenter gamePresenter = new GamePresenter(gameModel, gameView);

        gameModel.setGc(gameView.getCanvas().getGraphicsContext2D());
        gameModel.createGameLoop();

        Scene game = new Scene(gameView);

        primaryStage.setTitle("Opdracht");
        primaryStage.setScene(game);

        MenuModel model = new MenuModel();
        MenuView view = new MenuView();
        MenuPresenter presenter = new MenuPresenter(model, view);
        primaryStage.setScene(new Scene(view));
        view.getStylesheets().add("CSS//main.css");
        presenter.addWindowEventHandlers();

        primaryStage.setTitle("Brick Breaker");
        primaryStage.setWidth(800);
        primaryStage.setHeight(500);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
