package objects;

public enum spriteType {
    PLAYER, BLOCK, POWER, EXTRABALL;
}
