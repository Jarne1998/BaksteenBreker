package objects;

import javafx.geometry.Rectangle2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

import java.util.ArrayList;

public class RectangleSprite
{
    private Image image;
    private double positionX;
    private double positionY;
    private double velocityX;
    private double velocityY;
    private spriteType type;
    private double hitpoints;
    private double width;
    private double height;
    private ArrayList<RectangleSprite> ballsInRange;

    public RectangleSprite(spriteType type , double posX, double posY, double velocityX, double velocityY, String url) {
        this.type = type;
        this.image = new Image(url);
        this.positionX = posX;
        this.positionY = posY;
        this.velocityX = velocityX;
        this.velocityY = velocityY;

        this.height = image.getHeight();
        this.width = image.getWidth();
    }

    public RectangleSprite(spriteType type , double posX, double posY, String url, int hitPoints) {
        this.type = type;
        this.image = new Image(url);
        this.positionX = posX;
        this.positionY = posY;
        this.hitpoints = hitPoints;

        this.height = image.getHeight();
        this.width = image.getWidth();
        ballsInRange = new ArrayList<>();
    }

    public void update(double time)
    {
        if (positionX < 0 || positionX > 630) {
            velocityX = -velocityX;
        }
        if (positionY < 0) {
            velocityY = -velocityY;
        }

        positionX += velocityX ;
        positionY += velocityY ;
    }

    public void changeVelocity(RectangleSprite block) {
        if (type == spriteType.PLAYER) {
//            if (positionX + (image.getWidth() / 2) >= block.positionX + block.image.getHeight() || positionX + (image.getWidth() / 2) <= block.positionX) {
//                velocityX = -velocityX;
//            } else if (positionY + (image.getHeight() / 2) >= block.positionY + block.image.getWidth() || positionY + (image.getHeight() / 2) <= block.positionY) {
//                velocityY = -velocityY;
//            }
//

            if (positionX + (image.getWidth() /2 ) <= block.positionX || positionX + (image.getWidth() /2) >= block.positionX + block.image.getWidth()) {
                velocityX = -velocityX;
            }  else if (positionY + (image.getWidth() /2 ) <= block.positionY || positionY + (image.getWidth() /2) >= block.positionY + block.image.getHeight()) {
                velocityY = -velocityY;
            }
        }
    }

    public void takeDamage(double dmg) {
        hitpoints -= dmg;
    }

    public void render(GraphicsContext gc)
    {
        gc.drawImage( image, positionX, positionY);
        if (type == spriteType.BLOCK)
        gc.fillText(Double.toString(hitpoints), positionX+30, positionY+30, 60);
    }
 
    public Rectangle2D getBoundary()
    {
        return new Rectangle2D(positionX,positionY,width,height);
    }
 
    public boolean intersects(RectangleSprite r)
    {
        return r.getBoundary().intersects(this.getBoundary());
    }

    public double getHitpoints() {
        return hitpoints;
    }

    public double getPositionY() {
        return positionY;
    }

    public double getPositionX() {
        return positionX;
    }

    public void setPositionX(double positionX) {
        this.positionX = positionX;
    }

    public void setPositionY(double positionY) {
        this.positionY = positionY;
    }

    public spriteType getType() {
        return type;
    }

    public ArrayList<RectangleSprite> getBallsInRange() {
        return ballsInRange;
    }
}