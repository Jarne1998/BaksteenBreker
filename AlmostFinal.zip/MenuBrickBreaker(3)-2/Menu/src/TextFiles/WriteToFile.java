package TextFiles;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class WriteToFile {
    private BufferedWriter out;

    public void openFile(String fileName) {
        try {
            out = new BufferedWriter(new FileWriter(fileName, true));
        } catch (Exception ex) {
            System.out.println("Error open file");
        }
    }

    public void write(String name, int round) {
        try {
            out.write("\n" + name.trim() + "-" + round);
            out.flush();
        } catch (Exception ex) {
            System.out.println("Error write file");
        }
    }

    public void closeFile() {
        try {
            out.close();
        } catch (Exception ex) {
            System.out.println("Error close file");
        }
    }
}
