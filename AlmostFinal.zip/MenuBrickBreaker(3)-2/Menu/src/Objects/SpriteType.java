package Objects;

/**
 * De enumeratie SpriteType om het type van de klasse RectangleSprite te bepalen
 */
public enum SpriteType {
    PLAYER, BLOCK, POWER, POWER_HOR, POWER_VER, EXTRABALL;
}
