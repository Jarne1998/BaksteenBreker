package BickBreaker;

import BickBreaker.Model.GameModel;
import BickBreaker.Model.MenuModel;
import BickBreaker.view.game.GamePresenter;
import BickBreaker.view.game.GameView;
import BickBreaker.view.menu.MenuPresenter;
import BickBreaker.view.menu.MenuView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        MenuModel model = new MenuModel();
        MenuView view = new MenuView();
        MenuPresenter presenter = new MenuPresenter(model, view);
        primaryStage.setScene(new Scene(view));
        view.getStylesheets().add("CSS//main.css");
        presenter.addWindowEventHandlers();

        primaryStage.setTitle("Brick Breaker");
        primaryStage.setMinWidth(800);
        primaryStage.setMinHeight(500);
        primaryStage.setResizable(true);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
