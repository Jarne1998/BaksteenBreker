package BickBreaker.view.highscore;

import TextFiles.ReadFromFile;
import TextFiles.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.*;

import java.util.List;

public class HighscoreView extends VBox {
    private Label HighscoreLabel;
    private Button Back_btn;
    private TableView tableViewHighScore;
    private TableColumn nameCol;
    private TableColumn roundCol;


    public HighscoreView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        Back_btn = new Button("Terug");
        HighscoreLabel = new Label("Highscore");
        tableViewHighScore = new TableView();
        nameCol = new TableColumn("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        roundCol = new TableColumn("Round");
        roundCol.setCellValueFactory(new PropertyValueFactory<>("round"));
        ReadFromFile read = new ReadFromFile();
        read.openFile("Menu/resources/highscores.txt");
        tableViewHighScore.setItems(read.read());
        read.closeFile();
        tableViewHighScore.getColumns().addAll(nameCol, roundCol);
        tableViewHighScore.getSortOrder().add(roundCol);
    }

    private void layoutNodes() {

        setSpacing(10);
        setPadding(new Insets(10));
        getChildren().addAll(HighscoreLabel, tableViewHighScore,Back_btn);
        setAlignment(Pos.CENTER);


        this.setBackground(new Background(new BackgroundImage(new Image("Achtergrond9.jpg"), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, new BackgroundPosition(
                Side.LEFT, 0.0, false, Side.BOTTOM, 0.0, false), BackgroundSize.DEFAULT)));
    }

    public Button getNextScene() {
        return Back_btn;
    }
}
