package BickBreaker.view.game;

import BickBreaker.Model.GameModel;
import javafx.animation.AnimationTimer;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import Objects.RectangleSprite;

/**
 * De klasse GameView die er voor zorgt dat alles wordt gevisualizeerd
 */
public class GameView extends BorderPane {
    private Canvas canvas;
    private Button pauseButton;
    private Slider velocitySlider;
    private GraphicsContext gc;
    private Font customFontSize15;
    private Font customFontSize20;
    private Font pauseFontSize50;
    private AnimationTimer gameLoop;
    private Alert alert;
    private GameModel model;

    /**
     * Constructor van de klasse GameView.
     * Vult alle variabelen in en initialisieerd en localiseerd de Nodes
     */
    public GameView() {
        initialiseNodes();
        layoutNodes();
        customFontSize15 = Font.font(15);
        customFontSize20 = Font.font(20);
        pauseFontSize50 = Font.font(50);
        setStyle("-fx-background-color: black;");
        gc = canvas.getGraphicsContext2D();
        gc.setStroke(Color.WHITE);
        gc.setFill(Color.WHITE);
    }

    /**
     * Initialisatie van de Nodes
     */
    public void initialiseNodes() {
        canvas = new Canvas(660,900);
        pauseButton = new Button("Pause");
        velocitySlider = new Slider();

        velocitySlider.setMin(-5);
        velocitySlider.setMax(5);
        velocitySlider.setValue(0);
        velocitySlider.setShowTickLabels(false);
        velocitySlider.setShowTickMarks(false);
        velocitySlider.setMinHeight(50);
        velocitySlider.setMaxWidth(200);

        alert = new Alert(Alert.AlertType.NONE);
        alert.setTitle("GAME OVER");
        alert.setHeaderText("GAME OVER");
        ButtonType continueButton = new ButtonType("OK");
        alert.getButtonTypes().add(continueButton);
    }

    /**
     * Localisatie van de Nodes
     */
    public void layoutNodes() {
        BorderPane.setMargin(pauseButton, new Insets(10));
        BorderPane.setAlignment(pauseButton, Pos.CENTER_RIGHT);
        BorderPane.setAlignment(velocitySlider, Pos.CENTER);
        setTop(pauseButton);
        setCenter(canvas);
        setBottom(velocitySlider);
    }

    /**
     * Createerd de gameloop, het hart, van het spel en start deze.
     * @param model
     */
    public void createGameloop(GameModel model) {
        this.model = model;
        reDrawCanvas();
        reDrawCanvas();
        gameLoop = new AnimationTimer() {
            public void handle(long currentNanoTime) {
                try {
                    if(!model.getPlayerIsControlling() && !model.isPaused()) {
                        model.gameLoop();
                        reDrawCanvas();
                    }
                    if (model.isPaused()) {
                        gc.setFont(pauseFontSize50);
                        gc.fillText("Paused", 230,400);
                    }
                } catch (Exception ex) {
                    reDrawCanvas();
                    die();
                }
            }
        };

        gameLoop.start();
    }

    /**
     * Hertekent alles op het canvas na het proper te hebben gemaakt.
     */
    public void reDrawCanvas() {
        gc.clearRect(0, 0, 660, 900);
        gc.setFont(customFontSize20);
        for (RectangleSprite ball : model.getPlayerBalls()) {
            ball.render(gc);
        }

        for (RectangleSprite block : model.getBlocksInField()) {
            block.render(gc);
        }

        gc.setFont(customFontSize15);
        gc.fillText("Balls:" + Integer.toString(model.getMaxBalls()), 0,15);
        gc.fillText("Round:" + Integer.toString(model.getRound()), 330,15);
    }

    /**
     * Tekent het traject dat de bal zal volgen.
     *
     * @param coords de 5 coordinaten die nodig zijn om de lijnen te tekenen
     */
    public void drawTrajectory(double[] coords) {
        reDrawCanvas();
        gc.setLineWidth(1);
        gc.setLineDashes(20);
        gc.strokeLine(coords[4] + 15, 885, coords[0]  , coords[1]);
        gc.strokeLine(coords[0], coords[1], coords[2], coords[3]);
    }

    /**
     * Wanneer het spel afloopt wordt deze functie opgeroepen, deze stopt het spel
     */
    private void die() {
        gameLoop.stop();

        alert.setContentText(String.format("Je bent verloren, je behaalde ronde %d.", model.getRound()));

        alert.show();
    }

    /**
     * Standaard get
     *
     * @return geeft de pauseButton terug
     */
    public Button getPauseButton() {
        return pauseButton;
    }

    /**
     * Standaard get
     *
     * @return geeft de velocitySlider terug
     */
    public Slider getVelocitySlider() { return velocitySlider; }

    /**
     * Standaard get
     * @return geeft de alert terug
     */
    public Alert getAlert() {
        return alert;
    }
}
