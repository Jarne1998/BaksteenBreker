package BickBreaker.view.menu;

import BickBreaker.Model.HelpModel;
import BickBreaker.Model.HighscoreModel;
import BickBreaker.Model.MenuModel;
import BickBreaker.Model.NewGameModel;
import BickBreaker.view.help.HelpPresenter;
import BickBreaker.view.help.HelpView;
import BickBreaker.view.highscore.HighscorePresenter;
import BickBreaker.view.highscore.HighscoreView;
import BickBreaker.view.newgame.NewGamePresenter;
import BickBreaker.view.newgame.NewGameView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.VBox;

public class MenuPresenter extends VBox {
    private MenuModel model;
    private MenuView view;

    public MenuPresenter(MenuModel model, MenuView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getNewGameButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                NewGameView newGameView = new NewGameView();
                NewGameModel newGameModel = new NewGameModel();
                NewGamePresenter newGamePresenter = new NewGamePresenter(newGameView, newGameModel);
                view.getScene().setRoot(newGameView);
            }
        });
        view.getHighscoreButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                HighscoreView highscoreView = new HighscoreView();
                HighscoreModel highscoreModel = new HighscoreModel();
                HighscorePresenter highscorePresenter = new HighscorePresenter(highscoreView, highscoreModel);
                view.getScene().setRoot(highscoreView);
            }
        });

        view.getHelpButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                HelpView helpView = new HelpView();
                HelpModel helpModel = new HelpModel();
                HelpPresenter helpPresenter = new HelpPresenter(helpView, helpModel);
                view.getScene().setRoot(helpView);
            }
        });

    }

    public void updateView() {
    }

    public void addWindowEventHandlers() {
    }

    public MenuView getView() {
        return view;
    }
}
