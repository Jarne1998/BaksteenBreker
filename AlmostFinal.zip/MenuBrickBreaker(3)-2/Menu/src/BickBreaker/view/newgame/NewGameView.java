package BickBreaker.view.newgame;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class NewGameView extends VBox {
    private Label newGameLabel;
    private Label charachters;
    private Button nextScene;
    private Button menuBack_btn;
    private TextField gevenNaam;

    public NewGameView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {

        newGameLabel = new Label("New Game");
        gevenNaam = new TextField(" ");
        nextScene = new Button("Volgende");
        charachters = new Label("Geef hier je naam: (Max. 8 charachters)");
        menuBack_btn = new Button("Terug");
    }

    private void layoutNodes() {

        newGameLabel.setTextFill(Color.BLACK);
        charachters.setTextFill(Color.RED);
        gevenNaam.setAlignment(Pos.CENTER_LEFT);
        gevenNaam.setMaxWidth(200);
        newGameLabel.setLineSpacing(40);

        setSpacing(50);
        setPadding(new Insets(10));
        getChildren().addAll(newGameLabel, charachters, gevenNaam, nextScene, menuBack_btn);
        setAlignment(Pos.CENTER);

        this.setBackground(new Background(new BackgroundImage(new Image("Achtergrond9.jpg"), BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, new BackgroundPosition(
                Side.RIGHT, 0.0, false, Side.BOTTOM, 0.0, false), BackgroundSize.DEFAULT)));
    }

    public Button getNextScene() {
        return nextScene;
    }

    public TextField getGevenNaam() {
        return gevenNaam;
    }

    public Button getMenuBack_btn(){
        return menuBack_btn;
    }
}
