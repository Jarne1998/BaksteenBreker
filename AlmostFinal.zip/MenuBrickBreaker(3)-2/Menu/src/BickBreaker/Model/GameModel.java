package BickBreaker.Model;

import Objects.RectangleSprite;
import Objects.SpriteType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * De klasse GameModel is het brein achter het spel Brick breaker.
 * Alle blokken worden hier gegenereerd en er word bepaald wanneer er wat mag gebeuren
 *
 * @author Ruben
 * @version ?
 */
public class GameModel {
    private int round;
    private int timer;
    private boolean paused;
    private boolean playerIsControlling;
    private int maxBlocks;
    private int curBlocks;
    private int maxBalls;
    private int curBalls;
    private int ballsToAdd;
    private int hitPoints;
    private double startPosX;
    private double velocityX;
    private double velocityY;

    private List<RectangleSprite> playerBalls;
    private List<RectangleSprite> blocksInField;
    private List<RectangleSprite> hitBlocks;
    private List<RectangleSprite> blocksToRemoveAfterRound;
    private List<RectangleSprite> ballsGone;

    private List<Integer> blockPicker = new ArrayList<>();
    private List<Boolean> extraBallLocation = new ArrayList<>();
    private List<Boolean> blockYesNo = new ArrayList<>();
    private List<Integer> powerPicker = new ArrayList<>();
    private List<Boolean> doubleHealth = new ArrayList<>();

    /**
     * Constructor van de klasse GameModel.
     * Vult alle variabelen in en genereerd de startblokken die moeten worden getoond.
     */
    public GameModel() {
        //Initialize
        this.velocityX = 0;
        this.velocityY = -5;
        this.round = 0;
        this.timer = 0;
        this.paused = false;
        this.playerIsControlling = true;
        this.maxBlocks = 3;
        this.curBlocks = 0;
        this.maxBalls = 1;
        this.curBalls = 0;
        this.ballsToAdd = 0;
        this.startPosX = 120;
        this.hitPoints = round;

        this.playerBalls = new ArrayList<>();
        this.blocksInField = new ArrayList<>();
        this.hitBlocks = new ArrayList<>();
        this.blocksToRemoveAfterRound = new ArrayList<>();
        this.ballsGone = new ArrayList<>();


        //Randomizers
        //regular
        for (int i = 0; i< 75; i++) {
            blockPicker.add(0);
        }
        //power
        for(int i = 0; i<5; i++) {
            blockPicker.add(1);
        }

        for (int i = 0; i < 9; i++) {
            blockYesNo.add(false);
        }
        for (int i = 0; i < 11; i++) {
            blockYesNo.add(true);
        }

        for (int i = 0; i < 95; i++) {
            doubleHealth.add(false);
        }
        for (int i = 0; i < 5; i++) {
            doubleHealth.add(true);
        }

        powerPicker.add(0);
        powerPicker.add(1);
        powerPicker.add(2);

        //Load in blocks
        genNewBlocks();
    }

    /**
     * Veranderd van pause naar niet pause en visa versa.
     */
    public void setPaused() {
        this.paused = !this.paused;
    }

    /**
     * Veranderd van speler is in controle naar speler is niet in controle en visa versa.
     */
    public void setPlayerIsControlling() { this.playerIsControlling = !this.playerIsControlling; }

    /**
     * Standaard get
     *
     * @return geeft true of false terug
     */
    public boolean getPlayerIsControlling() { return this.playerIsControlling; }

    /**
     * Standaard get
     *
     * @return geeft de ronde terug
     */
    public int getRound() {
        return round;
    }

    /**
     * Standaard get
     *
     * @return geeft de maximum hoeveelheid ballen terug
     */
    public int getMaxBalls() {
        return maxBalls;
    }

    /**
     * Kijkt na of het spel gepauseerd is
     *
     * @return geeft true of false terug
     */
    public boolean isPaused() {
        return paused;
    }

    /**
     * Standaard get
     *
     * @return geeft een lijst van alle ballen die de speler bezit
     */
    public List<RectangleSprite> getPlayerBalls() {
        return playerBalls;
    }

    /**
     * Standaard get
     *
     * @return geeft een lijst terug van alle blokken die beschikbaar zijn
     */
    public List<RectangleSprite> getBlocksInField() {
        return blocksInField;
    }

    /**
     * Standaard set
     *
     * @param velocityX de kracht die op X moet worden uitgeoefend
     */
    public void setVelocityX(double velocityX) {
        this.velocityX = velocityX;
    }

    /**
     * Standaard set
     *
     * @param velocityY de kracht die op Y moet worden uitgeoefend
     */
    public void setVelocityY(double velocityY) {
        this.velocityY = velocityY;
    }

    /**
     * De hoofdloop die alles bepaalt wat er mag gebeuren en wat niet en wat er op volgt.
     *
     * @throws Exception indien de speler dood gaat
     */
    public void gameLoop() throws Exception {
        if (playerBalls.size() == 0 && timer == 0 && curBalls != 0) {

            moveBlocksDown();

            //Remove blocks that need to be removed after a round (mostly only power blocks)
            for (RectangleSprite block : blocksToRemoveAfterRound) {
                blocksInField.remove(block);
            }

            if (blocksInField.size() > 0) {
                if (blocksInField.get(0).getPositionY() >= 840) {
                    throw new Exception();
                }
            }

            resetRound();
        }

        genPlayerBalls();

        //Loop through all player balls
        for (RectangleSprite ball : playerBalls) {
            ball.update();
            //Loop through all blocks on field
            for (RectangleSprite block : blocksInField) {
                //Check the current ball intersects with the block and if the block is not already intersecting with the current ball
                if (ball.intersects(block) && !block.getBallsInRange().contains(ball)) {
                    block.getBallsInRange().add(ball);
                    //Regular block
                    if (block.getType() == SpriteType.BLOCK) {
                        doActionsRegularBlock(block, ball);
                        break;
                    } //Extra ball block
                    else if (block.getType() == SpriteType.EXTRABALL) {
                        doActionsExtraBallBlock(block);
                        break;
                    } //Power block
                    else if (block.getType() == SpriteType.POWER || block.getType() == SpriteType.POWER_VER || block.getType() == SpriteType.POWER_HOR) {
                        doActionsPowerBlock(block);
                        break;
                    }

                }
                if (!ball.intersects(block)) {
                    block.getBallsInRange().remove(ball);
                }
            }
            if (ball.getPositionY() > 870) {
                if (ballsGone.size() == 0) {
                    startPosX = ball.getPositionX();
                }
                ballsGone.add(ball);
            }
        }


        for (RectangleSprite block : hitBlocks) {
            if (block.getHitpoints() <= 0) {
                blocksInField.remove(block);
            }
        }

        for (RectangleSprite ball : ballsGone) {
            playerBalls.remove(ball);
        }

        hitBlocks.clear();
    }

    /**
     * Genereerd de ballen van de speler met een timer er tussen zodat zie niet direct allemaal op het canvas verschijnen.
     */
    private void genPlayerBalls() {
        if (curBalls < maxBalls && timer == 1) {
            playerBalls.add(new RectangleSprite(SpriteType.PLAYER,startPosX, 870,velocityX,velocityY, "/Ball.png"));
            timer = 0;
            curBalls++;
        } else if (curBalls < maxBalls) {
            timer++;
        }
    }

    /**
     * Genereerd een random hoeveelheid blokken die op het canvas moeten verschijnen en van welk type ze zijn
     */
    private void genNewBlocks() {
        for(int i = 0; i < maxBlocks; i++) {
            extraBallLocation.add(false);
        }
        extraBallLocation.add(true);

        Collections.shuffle(blockYesNo);
        Collections.shuffle(extraBallLocation);
        hitPoints += 1;
        for (int x = 0; x < 11; x++) {
            Collections.shuffle(doubleHealth);
            if(doubleHealth.get(0)) {
                hitPoints *= 2;
            }
            if (blockYesNo.get(x)) {
                Collections.shuffle(blockPicker);
                if (blockPicker.get(0) == 0 && curBlocks <= maxBlocks) {
                    if (!extraBallLocation.get(curBlocks)) {
                        blocksInField.add(new RectangleSprite(SpriteType.BLOCK, x * 60, 60, "/Block.png", hitPoints));
                    } else {
                        blocksInField.add(new RectangleSprite(SpriteType.EXTRABALL, x * 60 + 15, 60+15, "/ExtraBall.png", -1));
                    }
                    curBlocks++;
                } else if (blockPicker.get(0) == 1) {
                    Collections.shuffle(powerPicker);
                    switch (powerPicker.get(0)) {
                        case 0:
                            blocksInField.add(new RectangleSprite(SpriteType.POWER, x * 60 + 15, 60 + 15, "/Power.png", -1));
                            break;
                        case 1:
                            blocksInField.add(new RectangleSprite(SpriteType.POWER_HOR, x * 60 + 15, 60 + 15 + 7.5, "/Power_Hor.png", -1));
                            break;
                        case 2:
                            blocksInField.add(new RectangleSprite(SpriteType.POWER_VER, x * 60 + 15 + 7.5, 60 + 15, "/Power_Ver.png", -1));
                            break;
                    }

                }
            }
            if(doubleHealth.get(0)) {
                hitPoints/=2;
            }
        }
        extraBallLocation.clear();
    }

    /**
     * Verplaatst de blokken die nog in het spel zijn na de ronde een rij omlaag
     */
    private void moveBlocksDown() {
        for (RectangleSprite block: blocksInField) {
            block.setPositionY(block.getPositionY() + 60);
            if((block.getType() == SpriteType.EXTRABALL || block.getType() == SpriteType.POWER) && block.getPositionY() == 540) {
                blocksToRemoveAfterRound.add(block);
            }
        }
    }

    /**
     * Wanneer de ronde voorbij is wordt deze functie opgeroepen om alle gegevens die moeten worden gereset of verandered na een ronde uit te voeren
     */
    private void resetRound() {
        setPlayerIsControlling();
        blocksToRemoveAfterRound.clear();
        ballsGone.clear();
        round++;
        if(round%5 == 0 && round > 0 && maxBlocks < 11) {
            maxBlocks++;
        }
        curBlocks = 0;
        maxBalls += ballsToAdd;
        ballsToAdd=0;
        curBalls = 0;
        genNewBlocks();
    }

    /**
     * De acties die moeten gebeuren wanneer er tegen een blok van het type BLOCK word gebotst
     *
     * @param block het object waar tegen gebotst is
     * @param ball de bal die tegen de blok is gebotst
     */
    private void doActionsRegularBlock(RectangleSprite block, RectangleSprite ball) {
        ball.changeVelocity(block);
        block.takeDamage(1);
        if (!hitBlocks.contains(block)) {
            hitBlocks.add(block);
        }
    }

    /**
     * De acties die moeten gebeuren wanneer er tegen een blok van het type EXTRABALL is gebotst
     *
     * @param block het object waar tegen gebotst is
     */
    private void doActionsExtraBallBlock(RectangleSprite block) {
        hitBlocks.add(block);
        ballsToAdd++;
    }

    /**
     * De acties die moeten gebeuren wanneer er tegen een blok van het type POWER is gebotst
     *
     * @param block het object waar tegen gebotst is
     */
    private void doActionsPowerBlock(RectangleSprite block) {
        if (!blocksToRemoveAfterRound.contains(block)) {
            blocksToRemoveAfterRound.add(block);
        }
        for (RectangleSprite blockOnSameRow : blocksInField) {
            if ( blockOnSameRow.getType() == SpriteType.BLOCK) {
                if (block.getType() == SpriteType.POWER_HOR || block.getType() == SpriteType.POWER) {
                    if (blockOnSameRow.getPositionY() + 22.5 == block.getPositionY() || blockOnSameRow.getPositionY() + 15 == block.getPositionY()) {
                        blockOnSameRow.takeDamage(1);
                        if (!hitBlocks.contains(blockOnSameRow)) {
                            hitBlocks.add(blockOnSameRow);
                        }
                    }
                }
                if (block.getType() == SpriteType.POWER_VER  || block.getType() == SpriteType.POWER) {
                    if (blockOnSameRow.getPositionX() + 22.5 == block.getPositionX() || blockOnSameRow.getPositionX() + 15 == block.getPositionX()) {
                        blockOnSameRow.takeDamage(1);
                        if (!hitBlocks.contains(blockOnSameRow)) {
                            hitBlocks.add(blockOnSameRow);
                        }
                    }
                }
            }
        }

    }

    /**
     * Berekent de coordinaten om 2 lijnen te kunnen tekenen om een bal traject te kunnen uitlijnen om de gebruiker te helpen
     *
     * @param new_val de nieuwe waarde van de slider uit de presenter
     * @return geeft 5 coordinaten terug om de lijnen te kunnen tekenen
     */
    public double[] calculateTrajectory(double new_val) {
        double endX = startPosX + 15;
        double endY = 885;
        double end2X;
        double end2Y;
        double localVelocityX = velocityX;
        double localVelocityY = velocityY -1;
        while (endX >= 0 && endX <= 660 && endY >= 0) {
            endX += localVelocityX;
            endY += localVelocityY;
        }
        if (endX < 10 || endX > 650) {
            localVelocityX = -localVelocityX;
        }
        if (endY < 10) {
            localVelocityY = -localVelocityY;
        }

        end2X = endX;
        end2Y = endY;
        for(int i = 0; i < 30; i++) {
            end2X += localVelocityX;
            end2Y += localVelocityY;
        }

        //0=endX, 1=endY, 2=end2X, 3=end2Y, 4=startPosX
        double[] coords = {endX, endY, end2X, end2Y, startPosX};

        return coords;
    }
}

