package BickBreaker.Model;

public class NewGameModel {
}
