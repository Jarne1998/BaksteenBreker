package BickBreaker;

import BickBreaker.Model.MenuModel;
import BickBreaker.view.menu.MenuPresenter;
import BickBreaker.view.menu.MenuView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {

        MenuModel model = new MenuModel();
        MenuView view = new MenuView();
        MenuPresenter presenter = new MenuPresenter(model, view);
        primaryStage.setScene(new Scene(view));
        view.getStylesheets().add("CSS//main.css");
        presenter.addWindowEventHandlers();

        primaryStage.setTitle("Brick Breaker");
        primaryStage.setWidth(500);
        primaryStage.setHeight(500);
        primaryStage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
