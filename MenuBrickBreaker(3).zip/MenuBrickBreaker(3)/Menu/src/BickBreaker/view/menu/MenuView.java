package BickBreaker.view.menu;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;

public class MenuView extends VBox {
    private Button NewGameButton, HighscoreButton, HelpButton;
    private Label BrickBreakerLabel;

    public MenuView(){
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        NewGameButton = new Button("New Game");
        HighscoreButton = new Button("Highscore");
        HelpButton = new Button("Help");
        Image Title = new Image("/BrickBreakerTitle.png");
        this.BrickBreakerLabel = new Label("", new ImageView(Title));
    }

    private void layoutNodes(){
        setSpacing(10);
        setPadding(new Insets(10));
        getChildren().addAll(BrickBreakerLabel, NewGameButton, HighscoreButton, HelpButton);
        setAlignment(Pos.CENTER);
    }

    public Button getNewGameButton() {
        return NewGameButton;
    }

    public Button getHighscoreButton() {
        return HighscoreButton;
    }

    public Button getHelpButton() {
        return HelpButton;
    }
}
