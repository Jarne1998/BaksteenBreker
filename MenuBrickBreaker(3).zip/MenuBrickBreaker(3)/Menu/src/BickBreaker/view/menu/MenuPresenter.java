package BickBreaker.view.menu;

import BickBreaker.Model.HelpModel;
import BickBreaker.Model.HighscoreModel;
import BickBreaker.Model.MenuModel;
import BickBreaker.Model.NewGameModel;
import BickBreaker.view.help.HelpPresenter;
import BickBreaker.view.help.HelpView;
import BickBreaker.view.highscore.HighscorePresenter;
import BickBreaker.view.highscore.HighscoreView;
import BickBreaker.view.newgame.NewGamePresenter;
import BickBreaker.view.newgame.NewGameView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.VBox;
import javafx.stage.WindowEvent;

public class MenuPresenter extends VBox {
    private MenuModel model;
    private MenuView view;

    public MenuPresenter(MenuModel model, MenuView view) {
        this.model = model;
        this.view = view;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers() {
        view.getNewGameButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                NewGameView newGameView = new NewGameView();
                NewGameModel newGameModel = new NewGameModel();
                NewGamePresenter newGamePresenter = new NewGamePresenter(newGameView, newGameModel);
                view.getScene().setRoot(newGameView);
                newGameView.getScene().getWindow().sizeToScene();
            }
        });
        view.getHighscoreButton().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                HighscoreView highscoreView = new HighscoreView();
                HighscoreModel highscoreModel = new HighscoreModel();
                HighscorePresenter highscorePresenter = new HighscorePresenter(highscoreView, highscoreModel);
                view.getScene().setRoot(highscoreView);
                highscoreView.getScene().getWindow().sizeToScene();
            }
        });

    }

    public void updateView() {
    }

    public void addWindowEventHandlers() {
    }
}
