package BickBreaker.view.newgame;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class NewGameView extends VBox {
    private Label newGameLabel;
    private Label charachters;
    private Button nextScene, Back;
    private TextArea gevenNaam;

    HBox hBox = new HBox(50);

   /* public void gethBox() {
        getChildren().add(Back);
        setAlignment(Pos.TOP_LEFT);
        hBox.setAlignment(Pos.CENTER);
        Back = new Button("Back");
    } */


    public NewGameView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {

        newGameLabel = new Label("New Game");
        gevenNaam = new TextArea(" ");
        nextScene = new Button("Volgende");
        charachters = new Label("Geef hier je naam: (Max. 8 charachters)");

    }

    private void layoutNodes() {

        setSpacing(10);
        setPadding(new Insets(10));
        getChildren().addAll(newGameLabel, charachters, gevenNaam, nextScene);
        setAlignment(Pos.CENTER);


    }

    public Button getNextScene() {
        return nextScene;
    }
}
