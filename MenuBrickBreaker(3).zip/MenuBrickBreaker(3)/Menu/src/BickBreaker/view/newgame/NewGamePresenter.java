package BickBreaker.view.newgame;

import BickBreaker.Model.NewGameModel;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class NewGamePresenter {
    private NewGameView view;
    private NewGameModel model;

    public NewGamePresenter(NewGameView view, NewGameModel model) {
        this.model = model;
        this.view = view;
        this.addEventHandlers();
        this.updateView();
    }

    private void addEventHandlers() {
        view.getNextScene().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                NewGameView newGameView = new NewGameView();
                NewGameModel newGameModel = new NewGameModel();
                NewGamePresenter newGamePresenter = new NewGamePresenter(newGameView, newGameModel);
                view.getScene().setRoot(newGameView);
                newGameView.getScene().getWindow().sizeToScene();

              /*  view.getScene().getWindow().setOnCloseRequest(new EventHandler<WindowEvent>() {
                    @Override
                    public void handle(WindowEvent event) {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setHeaderText("Te veel charachters!");
                        alert.setTitle("Error");
                        alert.getButtonTypes().clear();
                        ButtonType OK = new ButtonType("OK");
                        alert.getButtonTypes().addAll(OK);
                        alert.showAndWait();
                        if (alert.getResult() == null || alert.getResult().equals(OK)) {
                            event.consume();
                        }
                    }
                }); */
            }
        });
    }

    private void updateView() {
    }

    public void addWindowEventHandlers() {
    }
}
