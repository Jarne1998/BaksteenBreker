package BickBreaker.view.highscore;

import BickBreaker.Model.HighscoreModel;

public class HighscorePresenter {
    private HighscoreView view;
    private HighscoreModel model;

    public HighscorePresenter(HighscoreView view, HighscoreModel model) {
        this.model = model;
        this.view = view;
    }
}
