package BickBreaker.view.highscore;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class HighscoreView extends VBox {
    private Label HighscoreLabel;
    private Button Backbtn;

    public HighscoreView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        Backbtn = new Button("Terug");
        HighscoreLabel = new Label("Highscore");
    }

    private void layoutNodes() {

        setSpacing(10);
        setPadding(new Insets(10));
        getChildren().addAll(HighscoreLabel, Backbtn);
        setAlignment(Pos.CENTER);

       /* getChildren().add(Back);
        setAlignment(Pos.TOP_LEFT); */
    }

    public Button getNextScene() {
        return Backbtn;
    }
}
