package BickBreaker.view.help;

import BickBreaker.Model.HelpModel;
import BickBreaker.Model.NewGameModel;
import BickBreaker.view.newgame.NewGamePresenter;
import BickBreaker.view.newgame.NewGameView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class HelpPresenter {
    private HelpView view;
    private HelpModel model;

    public HelpPresenter(HelpView view, HelpModel model) {
        this.model = model;
        this.view = view;
    }

    private void addEventHandlers() {
        view.getNextScene().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                NewGameView newGameView = new NewGameView();
                NewGameModel newGameModel = new NewGameModel();
                NewGamePresenter newGamePresenter = new NewGamePresenter(newGameView, newGameModel);
                view.getScene().setRoot(newGameView);
                newGameView.getScene().getWindow().sizeToScene();
            }
        });
    }
}