package BickBreaker.view.help;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class HelpView extends VBox {
    private Button Back;
    private Label Help;
    private Label Instructies1;
    private Label Instructies2;
    private Label Instructies3;

    public HelpView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {

        Help = new Label("Help");
        Back = new Button("Terug");
        Instructies1 = new Label(" hallo");
        Instructies2 = new Label("hallo2");
        Instructies3 = new Label("hallo3");
    }

    private void layoutNodes() {
        setSpacing(10);
        setPadding(new Insets(10));
        getChildren().addAll(Help, Instructies1, Instructies2, Instructies3, Back);
        setAlignment(Pos.CENTER);

       /* getChildren().add(Back);
        setAlignment(Pos.TOP_LEFT); */
    }

    public Button getNextScene() {
        return Back;
    }
}