package BickBreaker.Model;

public class HighscoreModel {
    public HighscoreModel() {
    }
}
