package BickBreaker.Model;

public class MenuModel {
    public MenuModel(){
    }
}
